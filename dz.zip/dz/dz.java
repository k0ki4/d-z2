package dz;
import static dz.ArrayOfNumbers.Array;
import static dz.BinarPoisk.Chislo;

public class dz {
    public static void main(String[] args) {
       ArrayOfNumbers aon = new ArrayOfNumbers();
       int[] arraybum = Array();
       Chislo(arraybum);


    }
}
